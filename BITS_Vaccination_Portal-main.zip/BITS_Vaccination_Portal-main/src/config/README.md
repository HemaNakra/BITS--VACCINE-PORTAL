# Server Configurations

Stores the following :-
- database configs
- proxy configs
- sessions configs
- oauth2 api creds

These are to be gitignored.